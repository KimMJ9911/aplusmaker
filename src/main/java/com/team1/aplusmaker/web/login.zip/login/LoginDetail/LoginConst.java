package com.team1.aplusmaker.web.login.LoginDetail;

import org.springframework.stereotype.Component;

@Component
public interface LoginConst {
    String Login_Member = "login_member";
}
